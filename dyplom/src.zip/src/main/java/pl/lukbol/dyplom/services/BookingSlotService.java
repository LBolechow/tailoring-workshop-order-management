package pl.lukbol.dyplom.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import pl.lukbol.dyplom.exceptions.ApplicationException;
import pl.lukbol.dyplom.repositories.OrderRepository;
import pl.lukbol.dyplom.repositories.UserRepository;

import java.util.Date;

/**
 * Authoritative availability check for writes, not for calendar previews.
 *
 * The caller MUST be @Transactional. A pessimistic lock on the employee row
 * serializes insert/edit operations for that employee in PostgreSQL. The
 * overlap query runs AFTER acquiring the lock and before the transaction
 * commits. That makes concurrent requests for the same interval safe.
 */
@Service
@RequiredArgsConstructor
public class BookingSlotService {

    private final UserRepository userRepository;
    private final OrderRepository orderRepository;

    @Transactional(propagation = Propagation.MANDATORY)
    public void lockAndCheckSlot(Long employeeId, Date start, Date end, Long excludedOrderId) {
        if (start == null || end == null || !end.after(start)) {
            throw new ApplicationException.InvalidDateException(
                    "Order end must be later than order start");
        }

        // PostgreSQL holds this row lock until the surrounding transaction ends.
        userRepository.findByIdForScheduling(employeeId)
                .orElseThrow(() -> new ApplicationException.UserNotFoundException(
                        "Employee not found (id=" + employeeId + ")"));

        boolean occupied = excludedOrderId == null
                ? orderRepository.existsOverlappingSlot(employeeId, start, end)
                : orderRepository.existsOverlappingSlotExcludingOrder(
                        employeeId, start, end, excludedOrderId);

        if (occupied) {
            throw new ApplicationException.OrderSlotConflictException(
                    "Employee already has an order overlapping the selected time range");
        }
    }
}
