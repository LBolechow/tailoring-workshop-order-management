package pl.lukbol.dyplom.utilities;

import pl.lukbol.dyplom.DTOs.date.DateRange;
import pl.lukbol.dyplom.exceptions.ApplicationException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public final class DateUtils {

    public static final ZoneId WARSAW_ZONE = ZoneId.of("Europe/Warsaw");
    private static final DateTimeFormatter OUTPUT_DATE_TIME =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

    private DateUtils() {
    }

    // Legacy helper retained for other callers and existing tests.
    public static Date parseDate(String dateString, String pattern) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        return dateFormat.parse(dateString);
    }

    /**
     * Order API accepts a Warsaw-local ISO datetime, e.g. 2026-11-02T09:30:00.
     * Date-only values remain supported for older callers, mapped to midnight.
     */
    public static Date parseOrderDateTime(String value) {
        if (value == null || value.isBlank()) {
            throw new ApplicationException.InvalidDateException("Order date must not be empty");
        }
        try {
            LocalDateTime localDateTime = value.length() == 10
                    ? LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE).atStartOfDay()
                    : LocalDateTime.parse(value, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            return Date.from(localDateTime.atZone(WARSAW_ZONE).toInstant());
        } catch (DateTimeException ex) {
            throw new ApplicationException.InvalidDateException(
                    "Invalid order date: expected yyyy-MM-dd'T'HH:mm:ss");
        }
    }

    public static DateRange parseOrderRange(String startValue, String endValue) {
        Date start = parseOrderDateTime(startValue);
        Date end = parseOrderDateTime(endValue);
        if (!end.after(start)) {
            throw new ApplicationException.InvalidDateException(
                    "Order end must be later than order start");
        }
        return new DateRange(start, end);
    }

    public static String formatOrderDateTime(Date value) {
        return OUTPUT_DATE_TIME.format(LocalDateTime.ofInstant(value.toInstant(), WARSAW_ZONE));
    }

    public static String formatDateTime(Calendar calendar) {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(calendar.getTime());
    }
}
